#pragma once
#include "stdafx.h"

using namespace irr;
using namespace scene;
using namespace System;

namespace IrrlichtLime {
namespace Scene {

public enum class BoneSkinningSpace
{
	Local = EBSS_LOCAL,
	Global = EBSS_GLOBAL
};

} // end namespace Scene
} // end namespace IrrlichtLime