#pragma once
#include "stdafx.h"

using namespace irr;
using namespace video;
using namespace System;

namespace IrrlichtLime {
namespace Video {

public enum class IndexType
{
	_16Bit = EIT_16BIT,
	_32Bit = EIT_32BIT
};

} // end namespace Video
} // end namespace IrrlichtLime