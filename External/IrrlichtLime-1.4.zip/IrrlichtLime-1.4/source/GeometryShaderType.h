#pragma once

#include "stdafx.h"

using namespace irr;
using namespace video;
using namespace System;

namespace IrrlichtLime {
namespace Video {

public enum class GeometryShaderType
{
	GS_4_0 = EGST_GS_4_0
};

} // end namespace Video
} // end namespace IrrlichtLime